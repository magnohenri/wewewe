---
title: "Condomínio Jardim das Flores"
type: "Condomínio"
address: "Rua das Flores, 123"
description: "Um condomínio tranquilo com áreas verdes e playground para crianças."
date: 2025-04-18T05:29:00Z
members: 15
premium: true
---
