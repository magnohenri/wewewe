---
title: "Vizinho Barulhento no 3º Andar"
community: "Condomínio Jardim das Flores"
author: "usuario_exemplo"
date: 2025-04-18T05:29:00Z
category: "Barulhento"
description: "Vizinho do apartamento 302 faz festas até tarde da noite nos finais de semana, perturbando o descanso dos outros moradores."
rating: 2
anonymous: false
verified: true
---
