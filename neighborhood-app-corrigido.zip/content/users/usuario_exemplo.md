---
username: "usuario_exemplo"
fullName: "Usuário Exemplo"
email: "usuario@exemplo.com"
bio: "Morador do Condomínio Jardim das Flores há 3 anos."
memberSince: 2025-04-18T05:29:00Z
premium: true
communities: ["Condomínio Jardim das Flores"]
reviewsCount: 1
---
