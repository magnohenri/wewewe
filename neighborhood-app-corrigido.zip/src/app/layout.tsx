import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import './globals.css'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { UserCircle, Menu, X, Home, Users, Star, Settings, LogIn } from 'lucide-react'

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin']
})

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin']
})

export const metadata: Metadata = {
  title: 'Neighborhood - Avalie seus vizinhos',
  description: 'Plataforma para avaliação de vizinhos e gestão de comunidades locais'
}

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <head>
        <script src="https://identity.netlify.com/v1/netlify-identity-widget.js" async></script>
      </head>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <div className="min-h-screen flex flex-col">
          <header className="border-b">
            <div className="container mx-auto px-4 py-3 flex justify-between items-center">
              <Link href="/" className="flex items-center">
                <span className="text-xl font-bold text-blue-600">Neighborhood</span>
              </Link>
              
              {/* Menu para desktop */}
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/" className="text-gray-600 hover:text-blue-600">Início</Link>
                <Link href="/communities" className="text-gray-600 hover:text-blue-600">Comunidades</Link>
                <Link href="/reviews" className="text-gray-600 hover:text-blue-600">Avaliações</Link>
                <Link href="/pricing" className="text-gray-600 hover:text-blue-600">Planos</Link>
              </nav>
              
              <div className="hidden md:flex items-center space-x-3">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/login">
                    <LogIn className="h-4 w-4 mr-2" />
                    Entrar
                  </Link>
                </Button>
                <Button size="sm" asChild>
                  <Link href="/signup">Cadastrar</Link>
                </Button>
              </div>
              
              {/* Menu para mobile (toggle com JavaScript seria implementado em um componente real) */}
              <div className="md:hidden flex items-center">
                <Button variant="ghost" size="icon" className="text-gray-500">
                  <Menu className="h-6 w-6" />
                </Button>
              </div>
            </div>
          </header>
          
          <main className="flex-grow">
            {children}
          </main>
          
          <footer className="bg-gray-50 border-t py-8">
            <div className="container mx-auto px-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                  <h3 className="font-bold text-lg mb-4">Neighborhood</h3>
                  <p className="text-gray-600">Avalie seus vizinhos e conecte-se com sua comunidade local.</p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-3">Links Rápidos</h4>
                  <ul className="space-y-2">
                    <li><Link href="/" className="text-gray-600 hover:text-blue-600">Início</Link></li>
                    <li><Link href="/communities" className="text-gray-600 hover:text-blue-600">Comunidades</Link></li>
                    <li><Link href="/reviews" className="text-gray-600 hover:text-blue-600">Avaliações</Link></li>
                    <li><Link href="/pricing" className="text-gray-600 hover:text-blue-600">Planos</Link></li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-3">Recursos</h4>
                  <ul className="space-y-2">
                    <li><Link href="/help" className="text-gray-600 hover:text-blue-600">Ajuda</Link></li>
                    <li><Link href="/faq" className="text-gray-600 hover:text-blue-600">FAQ</Link></li>
                    <li><Link href="/contact" className="text-gray-600 hover:text-blue-600">Contato</Link></li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-3">Legal</h4>
                  <ul className="space-y-2">
                    <li><Link href="/terms" className="text-gray-600 hover:text-blue-600">Termos de Uso</Link></li>
                    <li><Link href="/privacy" className="text-gray-600 hover:text-blue-600">Política de Privacidade</Link></li>
                  </ul>
                </div>
              </div>
              
              <div className="border-t mt-8 pt-6 text-center text-gray-500 text-sm">
                <p>&copy; {new Date().getFullYear()} Neighborhood. Todos os direitos reservados.</p>
              </div>
            </div>
          </footer>
        </div>
        
        {/* Script para Netlify Identity */}
        <script dangerouslySetInnerHTML={{
          __html: `
            if (window.netlifyIdentity) {
              window.netlifyIdentity.on("init", user => {
                if (!user) {
                  window.netlifyIdentity.on("login", () => {
                    document.location.href = "/admin/";
                  });
                }
              });
            }
          `
        }} />
      </body>
    </html>
  )
}
