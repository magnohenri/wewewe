'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Star, Filter, Search, MapPin } from 'lucide-react'
import { useState } from 'react'
import Link from 'next/link'

export default function Reviews() {
  const [searchTerm, setSearchTerm] = useState('')
  const [filterCategory, setFilterCategory] = useState('all')

  // Dados de exemplo para avaliações
  const reviews = [
    {
      id: 1,
      title: 'Vizinho Barulhento no 3º Andar',
      community: 'Condomínio Jardim das Flores',
      communityId: 1,
      author: 'usuario_exemplo',
      date: '18/04/2025',
      category: 'Barulhento',
      description: 'Vizinho do apartamento 302 faz festas até tarde da noite nos finais de semana, perturbando o descanso dos outros moradores.',
      rating: 2,
      verified: true
    },
    {
      id: 2,
      title: 'Problema com lixo na entrada',
      community: 'Condomínio Jardim das Flores',
      communityId: 1,
      author: 'morador_antigo',
      date: '10/04/2025',
      category: 'Comportamento Inadequado',
      description: 'Alguns moradores estão deixando lixo fora dos horários de coleta, causando mau cheiro na entrada do condomínio.',
      rating: 3,
      verified: true
    },
    {
      id: 3,
      title: 'Cheiro de maconha constante',
      community: 'Edifício Aurora',
      communityId: 2,
      author: 'anônimo',
      date: '05/04/2025',
      category: 'Fumante',
      description: 'Frequentemente sinto cheiro de maconha vindo de algum apartamento próximo ao meu. Isso acontece principalmente à noite.',
      rating: 1,
      verified: false
    },
    {
      id: 4,
      title: 'Vizinho prestativo',
      community: 'Rua das Palmeiras',
      communityId: 3,
      author: 'novo_morador',
      date: '12/04/2025',
      category: 'Comportamento Inadequado',
      description: 'Queria destacar o vizinho do número 45 que sempre ajuda quando precisamos. Muito atencioso com todos da rua.',
      rating: 5,
      verified: true
    },
    {
      id: 5,
      title: 'Música alta durante o dia',
      community: 'Edifício Horizonte',
      communityId: 5,
      author: 'trabalhador_remoto',
      date: '08/04/2025',
      category: 'Barulhento',
      description: 'Vizinho do 7º andar coloca música muito alta durante o dia, dificultando o trabalho remoto e estudos.',
      rating: 2,
      verified: true
    }
  ]

  const filteredReviews = reviews.filter(review => {
    const matchesSearch = review.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         review.community.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesFilter = filterCategory === 'all' || 
                         filterCategory === review.category.toLowerCase()
    
    return matchesSearch && matchesFilter
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Avaliações</h1>
          <p className="text-gray-600">Descubra o que as pessoas estão falando sobre seus vizinhos</p>
        </div>
        <Button className="mt-4 md:mt-0" asChild>
          <Link href="/reviews/create">Nova Avaliação</Link>
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border p-4 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Buscar avaliações..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-gray-500" />
            <select 
              className="border rounded-md p-2 bg-white"
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
            >
              <option value="all">Todas as categorias</option>
              <option value="barulhento">Barulhento</option>
              <option value="fumante">Fumante</option>
              <option value="comportamento inadequado">Comportamento Inadequado</option>
            </select>
          </div>
        </div>
      </div>

      <Tabs defaultValue="recent" className="mb-8">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="recent">Recentes</TabsTrigger>
            <TabsTrigger value="popular">Populares</TabsTrigger>
            <TabsTrigger value="highest">Melhor Avaliados</TabsTrigger>
            <TabsTrigger value="lowest">Pior Avaliados</TabsTrigger>
          </TabsList>
          <span className="text-sm text-gray-500">{filteredReviews.length} avaliações encontradas</span>
        </div>
        
        <TabsContent value="recent" className="mt-6">
          <div className="space-y-6">
            {filteredReviews.map(review => (
              <Card key={review.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-5">
                  <div className="flex justify-between items-start mb-3">
                    <Link href={`/reviews/${review.id}`} className="hover:text-blue-600">
                      <h3 className="font-semibold text-lg">{review.title}</h3>
                    </Link>
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                        />
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center mb-3">
                    <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                      review.category === 'Barulhento' 
                        ? 'bg-red-100 text-red-800' 
                        : review.category === 'Fumante'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-orange-100 text-orange-800'
                    }`}>
                      {review.category}
                    </span>
                    {review.verified && (
                      <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                        Verificado
                      </span>
                    )}
                  </div>
                  
                  <p className="text-gray-700 mb-4 line-clamp-2">{review.description}</p>
                  
                  <div className="flex items-center text-gray-500 mb-3">
                    <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                    <Link href={`/communities/${review.communityId}`} className="text-sm hover:text-blue-600">
                      {review.community}
                    </Link>
                  </div>
                  
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>Por: {review.author}</span>
                    <span>{review.date}</span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="popular" className="mt-6">
          <div className="space-y-6">
            {[...filteredReviews]
              .sort((a, b) => b.verified - a.verified)
              .map(review => (
                <Card key={review.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <div className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <Link href={`/reviews/${review.id}`} className="hover:text-blue-600">
                        <h3 className="font-semibold text-lg">{review.title}</h3>
                      </Link>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center mb-3">
                      <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                        review.category === 'Barulhento' 
                          ? 'bg-red-100 text-red-800' 
                          : review.category === 'Fumante'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-orange-100 text-orange-800'
                      }`}>
                        {review.category}
                      </span>
                      {review.verified && (
                        <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                          Verificado
                        </span>
                      )}
                    </div>
                    
                    <p className="text-gray-700 mb-4 line-clamp-2">{review.description}</p>
                    
                    <div className="flex items-center text-gray-500 mb-3">
                      <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                      <Link href={`/communities/${review.communityId}`} className="text-sm hover:text-blue-600">
                        {review.community}
                      </Link>
                    </div>
                    
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Por: {review.author}</span>
                      <span>{review.date}</span>
                    </div>
                  </div>
                </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="highest" className="mt-6">
          <div className="space-y-6">
            {[...filteredReviews]
              .sort((a, b) => b.rating - a.rating)
              .map(review => (
                <Card key={review.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <div className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <Link href={`/reviews/${review.id}`} className="hover:text-blue-600">
                        <h3 className="font-semibold text-lg">{review.title}</h3>
                      </Link>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center mb-3">
                      <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                        review.category === 'Barulhento' 
                          ? 'bg-red-100 text-red-800' 
                          : review.category === 'Fumante'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-orange-100 text-orange-800'
                      }`}>
                        {review.category}
                      </span>
                      {review.verified && (
                        <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                          Verificado
                        </span>
                      )}
                    </div>
                    
                    <p className="text-gray-700 mb-4 line-clamp-2">{review.description}</p>
                    
                    <div className="flex items-center text-gray-500 mb-3">
                      <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                      <Link href={`/communities/${review.communityId}`} className="text-sm hover:text-blue-600">
                        {review.community}
                      </Link>
                    </div>
                    
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Por: {review.author}</span>
                      <span>{review.date}</span>
                    </div>
                  </div>
                </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="lowest" className="mt-6">
          <div className="space-y-6">
            {[...filteredReviews]
              .sort((a, b) => a.rating - b.rating)
              .map(review => (
                <Card key={review.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <div className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <Link href={`/reviews/${review.id}`} className="hover:text-blue-600">
                        <h3 className="font-semibold text-lg">{review.title}</h3>
                      </Link>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center mb-3">
                      <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                        review.category === 'Barulhento' 
                          ? 'bg-red-100 text-red-800' 
                          : review.category === 'Fumante'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-orange-100 text-orange-800'
                      }`}>
                        {review.category}
                      </span>
                      {review.verified && (
                        <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                          Verificado
                        </span>
                      )}
                    </div>
                    
                    <p className="text-gray-700 mb-4 line-clamp-2">{review.description}</p>
                    
                    <div className="flex items-center text-gray-500 mb-3">
                      <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                      <Link href={`/communities/${review.communityId}`} className="text-sm hover:text-blue-600">
                        {review.community}
                      </Link>
                    </div>
                    
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Por: {review.author}</span>
                      <span>{review.date}</span>
                    </div>
                  </div>
                </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
