'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MapPin, Users, Star, Calendar, MessageCircle } from 'lucide-react'
import Link from 'next/link'

export default function CommunityDetail({ params }: { params: { id: string } }) {
  // Simulando dados de uma comunidade específica
  const community = {
    id: 1,
    title: 'Condomínio Jardim das Flores',
    type: 'Condomínio',
    address: 'Rua das Flores, 123',
    members: 15,
    premium: true,
    description: 'Um condomínio tranquilo com áreas verdes e playground para crianças. Localizado em uma região arborizada, oferece qualidade de vida para seus moradores com segurança 24 horas e diversas opções de lazer.',
    createdAt: '2025-01-15',
    admin: 'usuario_exemplo'
  }

  // Simulando avaliações para esta comunidade
  const reviews = [
    {
      id: 1,
      title: 'Vizinho Barulhento no 3º Andar',
      author: 'usuario_exemplo',
      date: '18/04/2025',
      category: 'Barulhento',
      description: 'Vizinho do apartamento 302 faz festas até tarde da noite nos finais de semana, perturbando o descanso dos outros moradores.',
      rating: 2,
      verified: true
    },
    {
      id: 2,
      title: 'Problema com lixo na entrada',
      author: 'morador_antigo',
      date: '10/04/2025',
      category: 'Comportamento Inadequado',
      description: 'Alguns moradores estão deixando lixo fora dos horários de coleta, causando mau cheiro na entrada do condomínio.',
      rating: 3,
      verified: true
    },
    {
      id: 3,
      title: 'Cheiro de maconha constante',
      author: 'anônimo',
      date: '05/04/2025',
      category: 'Fumante',
      description: 'Frequentemente sinto cheiro de maconha vindo de algum apartamento próximo ao meu. Isso acontece principalmente à noite.',
      rating: 1,
      verified: false
    }
  ]

  // Simulando membros da comunidade
  const members = [
    { id: 1, username: 'usuario_exemplo', joinedAt: '15/01/2025', reviewsCount: 5 },
    { id: 2, username: 'morador_antigo', joinedAt: '20/01/2025', reviewsCount: 3 },
    { id: 3, username: 'novo_morador', joinedAt: '10/03/2025', reviewsCount: 1 },
    { id: 4, username: 'visitante_frequente', joinedAt: '05/02/2025', reviewsCount: 2 }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/communities" className="text-blue-600 hover:underline mb-4 inline-block">
          &larr; Voltar para Comunidades
        </Link>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold">{community.title}</h1>
              {community.premium && (
                <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">Premium</span>
              )}
            </div>
            <p className="text-gray-600 mt-1">{community.type}</p>
          </div>
          <Button className="mt-4 md:mt-0">
            Participar da Comunidade
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">Sobre esta Comunidade</h2>
            <div className="flex items-center text-gray-500 mb-3">
              <MapPin className="h-5 w-5 mr-2" />
              <span>{community.address}</span>
            </div>
            <div className="flex items-center text-gray-500 mb-3">
              <Users className="h-5 w-5 mr-2" />
              <span>{community.members} membros</span>
            </div>
            <div className="flex items-center text-gray-500 mb-6">
              <Calendar className="h-5 w-5 mr-2" />
              <span>Criada em {community.createdAt}</span>
            </div>
            <p className="text-gray-700 mb-4">{community.description}</p>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-500">Administrada por <span className="font-medium">{community.admin}</span></p>
            </div>
          </Card>

          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Avaliações</h2>
              <Button>Nova Avaliação</Button>
            </div>

            {reviews.length > 0 ? (
              <div className="space-y-4">
                {reviews.map(review => (
                  <Card key={review.id} className="p-5">
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-semibold text-lg">{review.title}</h3>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center mb-3">
                      <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                        review.category === 'Barulhento' 
                          ? 'bg-red-100 text-red-800' 
                          : review.category === 'Fumante'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-orange-100 text-orange-800'
                      }`}>
                        {review.category}
                      </span>
                      {review.verified && (
                        <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                          Verificado
                        </span>
                      )}
                    </div>
                    <p className="text-gray-700 mb-3">{review.description}</p>
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>Por: {review.author}</span>
                      <span>{review.date}</span>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-6 text-center">
                <p className="text-gray-500">Nenhuma avaliação encontrada para esta comunidade.</p>
                <Button className="mt-4">Seja o primeiro a avaliar</Button>
              </Card>
            )}
          </div>
        </div>

        <div>
          <Card className="p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Estatísticas</h2>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500 mb-1">Avaliações</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold">{reviews.length}</span>
                  <MessageCircle className="h-5 w-5 text-gray-400" />
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Membros</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold">{community.members}</span>
                  <Users className="h-5 w-5 text-gray-400" />
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">Avaliação Média</p>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <span className="text-2xl font-bold mr-2">
                      {(reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length).toFixed(1)}
                    </span>
                    <Star className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                  </div>
                  <span className="text-sm text-gray-500">de 5</span>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Membros</h2>
            <Tabs defaultValue="recent">
              <TabsList className="w-full mb-4">
                <TabsTrigger value="recent" className="flex-1">Recentes</TabsTrigger>
                <TabsTrigger value="active" className="flex-1">Ativos</TabsTrigger>
              </TabsList>
              
              <TabsContent value="recent">
                <ul className="divide-y">
                  {members.map(member => (
                    <li key={member.id} className="py-3 flex justify-between items-center">
                      <div>
                        <p className="font-medium">{member.username}</p>
                        <p className="text-sm text-gray-500">Desde {member.joinedAt}</p>
                      </div>
                      <span className="text-sm text-gray-500">{member.reviewsCount} avaliações</span>
                    </li>
                  ))}
                </ul>
              </TabsContent>
              
              <TabsContent value="active">
                <ul className="divide-y">
                  {[...members].sort((a, b) => b.reviewsCount - a.reviewsCount).map(member => (
                    <li key={member.id} className="py-3 flex justify-between items-center">
                      <div>
                        <p className="font-medium">{member.username}</p>
                        <p className="text-sm text-gray-500">Desde {member.joinedAt}</p>
                      </div>
                      <span className="text-sm text-gray-500">{member.reviewsCount} avaliações</span>
                    </li>
                  ))}
                </ul>
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </div>
    </div>
  )
}
