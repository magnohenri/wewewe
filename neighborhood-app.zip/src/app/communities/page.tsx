'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { MapPin, Users, Filter, Search } from 'lucide-react'
import { useState } from 'react'
import Link from 'next/link'

export default function Communities() {
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState('all')

  // Dados de exemplo para comunidades
  const communities = [
    {
      id: 1,
      title: 'Condomínio Jardim das Flores',
      type: 'Condomínio',
      address: 'Rua das Flores, 123',
      members: 15,
      premium: true,
      description: 'Um condomínio tranquilo com áreas verdes e playground para crianças.'
    },
    {
      id: 2,
      title: 'Edifício Aurora',
      type: 'Edifício',
      address: 'Av. Principal, 456',
      members: 8,
      premium: false,
      description: 'Edifício residencial com 12 andares localizado no centro da cidade.'
    },
    {
      id: 3,
      title: 'Rua das Palmeiras',
      type: 'Rua',
      address: 'Bairro Central',
      members: 22,
      premium: false,
      description: 'Rua arborizada com casas e pequenos comércios locais.'
    },
    {
      id: 4,
      title: 'Condomínio Vista Verde',
      type: 'Condomínio',
      address: 'Rua dos Ipês, 789',
      members: 30,
      premium: true,
      description: 'Condomínio fechado com segurança 24h e área de lazer completa.'
    },
    {
      id: 5,
      title: 'Edifício Horizonte',
      type: 'Edifício',
      address: 'Av. Beira Mar, 1010',
      members: 12,
      premium: false,
      description: 'Edifício com vista para o mar e apartamentos espaçosos.'
    },
    {
      id: 6,
      title: 'Bairro Novo Horizonte',
      type: 'Bairro',
      address: 'Zona Leste',
      members: 45,
      premium: true,
      description: 'Bairro residencial com praças, escolas e comércio local.'
    }
  ]

  const filteredCommunities = communities.filter(community => {
    const matchesSearch = community.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         community.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         community.description.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesFilter = filterType === 'all' || 
                         (filterType === 'premium' && community.premium) ||
                         (filterType === community.type.toLowerCase())
    
    return matchesSearch && matchesFilter
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Comunidades</h1>
          <p className="text-gray-600">Encontre e participe de comunidades na sua região</p>
        </div>
        <Button className="mt-4 md:mt-0">
          Criar Nova Comunidade
        </Button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border p-4 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Buscar comunidades..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-gray-500" />
            <select 
              className="border rounded-md p-2 bg-white"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
            >
              <option value="all">Todos os tipos</option>
              <option value="condomínio">Condomínios</option>
              <option value="edifício">Edifícios</option>
              <option value="rua">Ruas</option>
              <option value="bairro">Bairros</option>
              <option value="premium">Premium</option>
            </select>
          </div>
        </div>
      </div>

      <Tabs defaultValue="grid" className="mb-8">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="grid">Grade</TabsTrigger>
            <TabsTrigger value="list">Lista</TabsTrigger>
          </TabsList>
          <span className="text-sm text-gray-500">{filteredCommunities.length} comunidades encontradas</span>
        </div>
        
        <TabsContent value="grid" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCommunities.map(community => (
              <Card key={community.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-5">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-semibold text-lg">{community.title}</h3>
                    {community.premium && (
                      <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">Premium</span>
                    )}
                  </div>
                  <div className="flex items-center text-gray-500 mb-2">
                    <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                    <span className="text-sm truncate">{community.address}</span>
                  </div>
                  <div className="flex items-center text-gray-500 mb-3">
                    <Users className="h-4 w-4 mr-1 flex-shrink-0" />
                    <span className="text-sm">{community.members} membros</span>
                  </div>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">{community.description}</p>
                  <Button variant="default" className="w-full" asChild>
                    <Link href={`/communities/${community.id}`}>Ver Detalhes</Link>
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="list" className="mt-6">
          <div className="space-y-4">
            {filteredCommunities.map(community => (
              <Card key={community.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="p-5">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="flex-grow">
                      <div className="flex items-start gap-2 mb-2">
                        <h3 className="font-semibold text-lg">{community.title}</h3>
                        {community.premium && (
                          <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">Premium</span>
                        )}
                      </div>
                      <div className="flex items-center text-gray-500 mb-2">
                        <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                        <span className="text-sm">{community.address}</span>
                      </div>
                      <div className="flex items-center text-gray-500 mb-3">
                        <Users className="h-4 w-4 mr-1 flex-shrink-0" />
                        <span className="text-sm">{community.members} membros</span>
                      </div>
                      <p className="text-gray-600 text-sm">{community.description}</p>
                    </div>
                    <div className="mt-4 md:mt-0 md:ml-4 flex-shrink-0">
                      <Button variant="default" asChild>
                        <Link href={`/communities/${community.id}`}>Ver Detalhes</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
