'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { UserCircle, Settings, Star, MapPin, Calendar, Mail } from 'lucide-react'
import Link from 'next/link'

export default function Profile() {
  // Dados de exemplo para o perfil do usuário
  const user = {
    username: 'usuario_exemplo',
    fullName: 'Usuário Exemplo',
    email: 'usuario@exemplo.com',
    bio: 'Morador do Condomínio Jardim das Flores há 3 anos.',
    memberSince: '18/01/2025',
    premium: true,
    reviewsCount: 5,
    communitiesCount: 2
  }

  // Dados de exemplo para as avaliações do usuário
  const userReviews = [
    {
      id: 1,
      title: 'Vizinho Barulhento no 3º Andar',
      community: 'Condomínio Jardim das Flores',
      communityId: 1,
      date: '18/04/2025',
      category: 'Barulhento',
      rating: 2,
      verified: true
    },
    {
      id: 2,
      title: 'Problema com lixo na entrada',
      community: 'Condomínio Jardim das Flores',
      communityId: 1,
      date: '10/04/2025',
      category: 'Comportamento Inadequado',
      rating: 3,
      verified: true
    }
  ]

  // Dados de exemplo para as comunidades do usuário
  const userCommunities = [
    {
      id: 1,
      title: 'Condomínio Jardim das Flores',
      type: 'Condomínio',
      address: 'Rua das Flores, 123',
      members: 15,
      premium: true,
      role: 'Administrador'
    },
    {
      id: 3,
      title: 'Rua das Palmeiras',
      type: 'Rua',
      address: 'Bairro Central',
      members: 22,
      premium: false,
      role: 'Membro'
    }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Meu Perfil</h1>
        <p className="text-gray-600">Gerencie suas informações e atividades</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <Card className="p-6 mb-6">
            <div className="flex flex-col items-center text-center mb-6">
              <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <UserCircle className="w-16 h-16 text-blue-600" />
              </div>
              <h2 className="text-xl font-bold">{user.fullName}</h2>
              <p className="text-gray-500">@{user.username}</p>
              {user.premium && (
                <span className="mt-2 bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                  Conta Premium
                </span>
              )}
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center text-gray-700">
                <Mail className="h-5 w-5 mr-2 text-gray-500" />
                <span>{user.email}</span>
              </div>
              <div className="flex items-center text-gray-700">
                <Calendar className="h-5 w-5 mr-2 text-gray-500" />
                <span>Membro desde {user.memberSince}</span>
              </div>
            </div>
            
            <p className="text-gray-700 mb-6">{user.bio}</p>
            
            <div className="flex justify-center space-x-3">
              <Button variant="outline" size="sm" className="flex-1">
                <Settings className="h-4 w-4 mr-2" />
                Editar Perfil
              </Button>
              {!user.premium && (
                <Button size="sm" className="flex-1">
                  Upgrade Premium
                </Button>
              )}
            </div>
          </Card>
          
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Estatísticas</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 p-3 rounded-lg text-center">
                <p className="text-2xl font-bold text-blue-600">{user.reviewsCount}</p>
                <p className="text-sm text-gray-600">Avaliações</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg text-center">
                <p className="text-2xl font-bold text-blue-600">{user.communitiesCount}</p>
                <p className="text-sm text-gray-600">Comunidades</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg text-center">
                <p className="text-2xl font-bold text-blue-600">
                  {userReviews.length > 0 
                    ? (userReviews.reduce((acc, review) => acc + review.rating, 0) / userReviews.length).toFixed(1)
                    : '0.0'
                  }
                </p>
                <p className="text-sm text-gray-600">Média de Avaliação</p>
              </div>
              <div className="bg-gray-50 p-3 rounded-lg text-center">
                <p className="text-2xl font-bold text-blue-600">
                  {userReviews.filter(review => review.verified).length}
                </p>
                <p className="text-sm text-gray-600">Verificadas</p>
              </div>
            </div>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Tabs defaultValue="reviews">
            <TabsList className="w-full mb-6">
              <TabsTrigger value="reviews" className="flex-1">Minhas Avaliações</TabsTrigger>
              <TabsTrigger value="communities" className="flex-1">Minhas Comunidades</TabsTrigger>
            </TabsList>
            
            <TabsContent value="reviews">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Avaliações Recentes</h3>
                <Button asChild>
                  <Link href="/reviews/create">Nova Avaliação</Link>
                </Button>
              </div>
              
              {userReviews.length > 0 ? (
                <div className="space-y-4">
                  {userReviews.map(review => (
                    <Card key={review.id} className="p-5 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-3">
                        <Link href={`/reviews/${review.id}`} className="hover:text-blue-600">
                          <h4 className="font-semibold text-lg">{review.title}</h4>
                        </Link>
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                            />
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex items-center mb-3">
                        <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                          review.category === 'Barulhento' 
                            ? 'bg-red-100 text-red-800' 
                            : review.category === 'Fumante'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-orange-100 text-orange-800'
                        }`}>
                          {review.category}
                        </span>
                        {review.verified && (
                          <span className="ml-2 bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                            Verificado
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center text-gray-500 mb-3">
                        <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                        <Link href={`/communities/${review.communityId}`} className="text-sm hover:text-blue-600">
                          {review.community}
                        </Link>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-500">{review.date}</span>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">Editar</Button>
                          <Button variant="destructive" size="sm">Excluir</Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-6 text-center">
                  <p className="text-gray-500 mb-4">Você ainda não fez nenhuma avaliação.</p>
                  <Button asChild>
                    <Link href="/reviews/create">Criar Primeira Avaliação</Link>
                  </Button>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="communities">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Comunidades Participantes</h3>
                <Button asChild>
                  <Link href="/communities/create">Nova Comunidade</Link>
                </Button>
              </div>
              
              {userCommunities.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {userCommunities.map(community => (
                    <Card key={community.id} className="p-5 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start mb-3">
                        <Link href={`/communities/${community.id}`} className="hover:text-blue-600">
                          <h4 className="font-semibold text-lg">{community.title}</h4>
                        </Link>
                        {community.premium && (
                          <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                            Premium
                          </span>
                        )}
                      </div>
                      
                      <div className="flex items-center text-gray-500 mb-2">
                        <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
                        <span className="text-sm">{community.address}</span>
                      </div>
                      
                      <div className="flex items-center text-gray-500 mb-3">
                        <Users className="h-4 w-4 mr-1 flex-shrink-0" />
                        <span className="text-sm">{community.members} membros</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className={`text-sm px-2 py-1 rounded-full ${
                          community.role === 'Administrador'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {community.role}
                        </span>
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/communities/${community.id}`}>Gerenciar</Link>
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-6 text-center">
                  <p className="text-gray-500 mb-4">Você ainda não participa de nenhuma comunidade.</p>
                  <Button asChild>
                    <Link href="/communities">Explorar Comunidades</Link>
                  </Button>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
