'use client'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Star, AlertCircle } from 'lucide-react'
import { useState } from 'react'
import Link from 'next/link'

export default function CreateReview() {
  const [rating, setRating] = useState<number>(0)
  const [isAnonymous, setIsAnonymous] = useState(false)
  
  // Simulando dados de comunidades para o select
  const communities = [
    { id: 1, title: 'Condomínio Jardim das Flores' },
    { id: 2, title: 'Edifício Aurora' },
    { id: 3, title: 'Rua das Palmeiras' },
    { id: 4, title: 'Condomínio Vista Verde' },
    { id: 5, title: 'Edifício Horizonte' },
    { id: 6, title: 'Bairro Novo Horizonte' }
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/reviews" className="text-blue-600 hover:underline mb-4 inline-block">
          &larr; Voltar para Avaliações
        </Link>
        
        <h1 className="text-3xl font-bold mb-2">Nova Avaliação</h1>
        <p className="text-gray-600">Compartilhe sua experiência com a vizinhança</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="p-6">
            <form className="space-y-6">
              <div>
                <label htmlFor="title" className="block text-sm font-medium mb-2">
                  Título da Avaliação
                </label>
                <Input id="title" placeholder="Ex: Vizinho barulhento no apartamento 302" />
              </div>
              
              <div>
                <label htmlFor="community" className="block text-sm font-medium mb-2">
                  Comunidade
                </label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma comunidade" />
                  </SelectTrigger>
                  <SelectContent>
                    {communities.map(community => (
                      <SelectItem key={community.id} value={community.id.toString()}>
                        {community.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label htmlFor="category" className="block text-sm font-medium mb-2">
                  Categoria
                </label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="barulhento">Barulhento</SelectItem>
                    <SelectItem value="fumante">Fumante</SelectItem>
                    <SelectItem value="comportamento">Comportamento Inadequado</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">
                  Avaliação
                </label>
                <div className="flex items-center gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className="focus:outline-none"
                    >
                      <Star 
                        className={`h-8 w-8 ${
                          star <= rating 
                            ? 'text-yellow-400 fill-yellow-400' 
                            : 'text-gray-300'
                        }`} 
                      />
                    </button>
                  ))}
                </div>
                <p className="text-sm text-gray-500">
                  {rating === 1 && 'Péssimo'}
                  {rating === 2 && 'Ruim'}
                  {rating === 3 && 'Regular'}
                  {rating === 4 && 'Bom'}
                  {rating === 5 && 'Excelente'}
                </p>
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium mb-2">
                  Descrição
                </label>
                <Textarea 
                  id="description" 
                  placeholder="Descreva sua experiência em detalhes..." 
                  rows={5}
                />
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="anonymous"
                  checked={isAnonymous}
                  onChange={() => setIsAnonymous(!isAnonymous)}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="anonymous" className="ml-2 block text-sm text-gray-700">
                  Publicar anonimamente
                </label>
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 flex items-start">
                <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <h3 className="text-sm font-medium text-yellow-800">Diretrizes da comunidade</h3>
                  <div className="mt-1 text-sm text-yellow-700">
                    <p>Lembre-se de seguir nossas diretrizes ao fazer uma avaliação:</p>
                    <ul className="list-disc pl-5 mt-1 space-y-1">
                      <li>Seja respeitoso e objetivo</li>
                      <li>Não compartilhe informações pessoais</li>
                      <li>Baseie-se em fatos e experiências reais</li>
                      <li>Evite linguagem ofensiva ou discriminatória</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end gap-3">
                <Button variant="outline" type="button" asChild>
                  <Link href="/reviews">Cancelar</Link>
                </Button>
                <Button type="submit">Publicar Avaliação</Button>
              </div>
            </form>
          </Card>
        </div>

        <div>
          <Card className="p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Dicas para uma boa avaliação</h2>
            <ul className="space-y-3">
              <li className="flex gap-2">
                <span className="text-blue-600 font-bold">1.</span>
                <p className="text-gray-700">Seja específico sobre o comportamento ou situação que você está avaliando.</p>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600 font-bold">2.</span>
                <p className="text-gray-700">Mencione a frequência e duração do problema (ex: "festas barulhentas todos os finais de semana").</p>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600 font-bold">3.</span>
                <p className="text-gray-700">Inclua detalhes relevantes como horário, local específico e impacto causado.</p>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600 font-bold">4.</span>
                <p className="text-gray-700">Evite exageros e mantenha-se fiel aos fatos que você presenciou.</p>
              </li>
              <li className="flex gap-2">
                <span className="text-blue-600 font-bold">5.</span>
                <p className="text-gray-700">Se possível, mencione tentativas de resolução do problema que já foram feitas.</p>
              </li>
            </ul>
          </Card>
          
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Benefícios Premium</h2>
            <p className="text-gray-700 mb-4">Com uma conta premium, você pode:</p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-center gap-2">
                <span className="text-green-500">✓</span>
                <span>Fazer avaliações detalhadas</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-500">✓</span>
                <span>Adicionar fotos às avaliações</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-500">✓</span>
                <span>Receber notificações de novas avaliações</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="text-green-500">✓</span>
                <span>Filtros avançados de busca</span>
              </li>
            </ul>
            <Button variant="outline" className="w-full">
              Conheça nossos planos
            </Button>
          </Card>
        </div>
      </div>
    </div>
  )
}
